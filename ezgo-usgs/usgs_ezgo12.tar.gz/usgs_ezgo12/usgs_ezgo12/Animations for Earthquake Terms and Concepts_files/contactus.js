/**
 * This file contains the source code for the ContactForm Javascript object.
 * This object requests the contact form via AJAX and displays the form to the
 * user using a modal-style dialog box. The form is subsequently validated using
 * the ContactValidator class and upon successful validation, is submitted over
 * AJAX.
 *
 * A single instance of this class can handle links to multiple contact forms on
 * a single page. However the look and feel of the modal display will be
 * consistent.
 *
 * The modal dialog is opened in the function returned by the
 * "getOpenContactCallback". The method itself is a wrapping "getter" method
 * around a window click-event. The returned method should be bound to a contact
 * link <a> tag. The form will be fetched from the "href" attribute of that
 * anchor.
 *
 * When submitting the form, it will be submitted to the "action" attribute of
 * the form that is returned. The target of the "action" parameter should return
 * markup with a single root element suitable for display in a subsequent modal
 * dialog.
 *
 * All AJAX requests made by this class include the "ajax=true" query string
 * parameter. Server-side pages can test for this parameter to check if the
 * request should be wrapped in the template (i.e. "ajax" query string parameter
 * is not set), or not.
 *
 * @author emartinez
 * @date   2010/09/20
 * @see ContactValidator.js
 * @see FAQFilter.js
 *
 *
 * -- Dependencies --
 * Note: Update this if you ever re-package this into the site JS library.
 *
 * @import /contactus/js/ContactValidator.js
 * @import /contactus/js/FAQFilter.js
 * @widget ui
 *
 *
 * -- Changelog --
 * Revision 1: Updated the autocomplete to trigger the FAQFilter update when the
 * user clicks an option from the autocomplete overlay.
 */



/**
 * Constructore for the ContactForm object.
 *
 * @param options {Object} OPTIONAL - Options to customize the behavior of the
 *  contact form. These are taken directly from the jQuery UI Dialog object
 *
 * @see http://jqueryui.com/demos/dialog/
 */
ContactForm = function(options) {
	this._options = {
		/** Defaults **/
		"dialog": {
			"autoOpen": true,
			"draggable": true,
			"resizable": true,
			"modal": true,
			"title": "Contact Us",
			"close": this.getCloseContactCallback(),
			// -- Computed at window load time based on window size. -- //
			"width": Math.min(850, $('body').width()-50),
			"height": Math.min(540, $('body').height()-50)
		}
	};

	for (var o in options) { this._options[o] = options[o]; }
	this._dialog = null;
	this._validator = new ContactValidator(this);
	this._faqfilter = null;
};

/**
 * Returns a callback method to be called when the user clicks on a "contact"
 * form link in the page. We must wrap the method in a "getter" method in order
 * to expose the "ContactForm" JS object via "me"
 *
 * @return A callback function. See inner documentation for details.
 */
ContactForm.prototype.getOpenContactCallback = function() {
	var me = this;
	/**
	 * The returned function is the click handler for when the user clicks on a
	 * "contact" form link. The scope of "this" within the function refers to
	 * the clicked anchor link. To reference the "ContactForm" JS object use
	 * "me".
	 *
	 * @param event - The click event that triggered this method.
	 */
	return function(event) {
		me._appendCss();

		$.ajax({
			"url": $(this).attr('href'),
			"method": "GET",
			"cache": false,
			"data": {"ajax": "true"},
			"success": me.getCreateDialog(),
			"error": me.handleAjaxError
		});
		return false;
	};
};

ContactForm.prototype._appendCss = function() {
	if ($('#contactformcss').length == 0) {
		$('head').append(
			'<link id="contactformcss" rel="stylesheet" media="all" ' +
				'href="/contactus/css/contactform.css"/>'
		);
	}
};

ContactForm.prototype.getCloseContactCallback = function() {
	var me = this;
	/**
	 * The returned function is called when the dialog is closed. It fully
	 * destroys the dialog object and removes all traces of it from the DOM.
	 * This is important so subsequent contact forms (which may be different
	 * from each other) all properly bind their handlers.
	 *
	 * Within this returned function the "this" keyword refers to the contact
	 * form DOM element. To references the ContactForm JS object use "me".
	 */
	return function() {
		try {
			$(me._dialog).dialog("destroy");
			$(this).remove(); // "this" refers to the #contactform
		} catch (e) { /* Oh well. :( */ }
		me._dialog = null;
	};
};


/**
 * Returns a callback method to be called when the AJAX request for modal-style
 * content returns.
 */
ContactForm.prototype.getCreateDialog = function() {
	var me = this;
	/**
	 * The returned function is a callback from an XMLHttpRequest "success"
	 * callback using jQuery.ajax. The returned data contains the form markup.
	 * This method ensures all previously created dialogs are closed, destroyed,
	 * and removed from the DOM, then creates and displays a new dialog with the
	 * incoming data.
	 *
	 * Within this function one should not refer to "this". Rather use "me" to
	 * reference the "ContactForm" JS object.
	 *
	 * @param data {String} HTML markup for the contact form to display.
	 * @param status {String} Text status for the request.
	 * @param xmlhttp {XMLHttpRequest} The request object that triggered this
	 * callback
	 *
	 * @changelog - rev 1
	 */
	return function(data, status, xmlhttp) {
		if (me._dialog || $('#contactform').length > 0) {
			// Close the dialog (it might be open or not)
			$(me._dialog).dialog("close");
		}
		
		me._dialog = $(data).dialog(me._options["dialog"]);
		me._bindValidator();
		
		// Add autocomplete
		var subject_autocomplete_options = [];
		$('option', $('#contact_subject_autocomplete')).each(function() {
			subject_autocomplete_options.push($(this).val());
		});

		$('#contact_subject').autocomplete({
			"delay": 250,
			"source": subject_autocomplete_options,
			"select": function(event, ui) {
				$(this).val(ui.item.label);
				$(this).keyup();
			}
		});
		
		// Add FAQ filter
		me._faqfilter = new FAQFilter('#contactform_faq_questions');
		$('#contact_subject').keyup(function(event) {
			me._faqfilter.update($(this).val());
		}).keyup();
	};
};

/**
 * Binds the ContactValidator to the input fields on the contact form. This
 * method expects there to be an "email", "subject", and "message" field. If any
 * of these fields don't exist there is no penalty, but no other fields will be
 * validated either.
 */
ContactForm.prototype._bindValidator = function() {
	$('#contact_email').blur(this._validator.getValidateEmail());
	$('#contact_subject').blur(this._validator.getValidateSubject());
	$('#contact_message').blur(this._validator.getValidateMessage());
	$('#contactform_form').submit(this._validator.getValidateSubmit());
};

/**
 * This method is called when the form is submitted and successfully passes
 * validation. It sumbits the form over AJAX, closes the current modal dialog
 * and sets the AJAX submission callback to the ContactForm.getCreateDialog()
 * return method.
 *
 * @param form The form to submit.
 */
ContactForm.prototype.submitForm = function(form) {
	// Read the form parameters first
	var url = $(form).attr("action");
	var data = [
				$(form).serialize(),
				'ajax=true',
				'submit=Send+Message'
			].join('&');

	// Close the current dialog
	$(this._dialog).dialog("close");

	// Submit the form via ajax
	$.ajax({
		"url": url,
		"method": "POST",
		"cache": false,
		"data": data,
		"success": this.getCreateDialog(),
		"error": this.handleAjaxError
	});

	return false;
};

/**
 * Callback method when an error occurs during an AJAX request.
 *
 * @TODO Make this method/entire process more graceful.
 *
 * @param xmlhttp {XMLHttpRequest} The ajax request that triggered this method.
 * @param status {String} The text status describing the error.
 * @param error {Object} The actual error thrown.
 */
ContactForm.prototype.handleAjaxError = function(xmlhttp, status, error) {
	alert(
		[
			"An error occurred while fetching data from the server. (", 
			status, 
			"). Please try again."
		].join("")
	);
};/**
 * This class is a validator for the EHP contact form. It is not generalized in
 * any way. Modifications to this class need coincide carefully with
 * modifications to the form itself.
 *
 *
 * @TODO Improve validator to work with more common forms. Make more generic.
 *
 * @author emartinez
 * @date   2010/09/20
 *
 * @widgets jquery
 */


/**
 * This is the constructor for an email validator class.
 *
 * @param contactForm {DOM} The contact form to validate.
 */
ContactValidator = function(contactForm) {
	this._contactForm = contactForm;
};

/**
 * This method validates an email address. Email address is an optional field.
 * An email is considered valid if it is either empty, or if it _looks_ like an 
 * email address. No checking is done to verify if the address is real or not.
 *
 * If the email address fails to validate then an error message is appended 
 * below the email input field.
 */
ContactValidator.prototype.getValidateEmail = function() {
	var me = this;
	return function(event) {
		var value = $(this).val();
		// If non-empty and not valid then fail
		if (value != '' && ! value.match(/^[\S]+@[\S]+\.[\S]+$/)) {
			$(this).parent('li').append([
				'<span class="inputError">',
					'You must either omit the email address or ',
					'enter a valid email address.',
				'</span>'
			].join(""));
		}
		// If empty or non-empty and valid then pass 
		else {
			try {
				// Remove the previous error if it now passes
				$('.inputError', $(this).parent('li')).remove();
			} catch (e) { /** Just means it isn't there. **/ }
		}
	};
};

/**
 * This method validates an email subject. An email subject is required and is 
 * considered valid as long as it is not empty.
 *
 * If the email subject fails to validate then an error message is appended 
 * below the subject input field.
 */
ContactValidator.prototype.getValidateSubject = function() {
	var me = this;
	return function(event) {
		var value = $(this).val();
		// If value is empty then fail
		if (value == '') {
			$(this).parent('li').append([
				'<span class="inputError">',
					'You must enter a subject.',
				'</span>'
			].join(""));
		}
		// If value is non-empty then pass
		else {
			try {
				// Remove the previous error if it now passes
				$('.inputError', $(this).parent('li')).remove();
			} catch (e) { /** Just means it isn't there. **/ }
		}
	};
};

/**
 * This method validates an email message. An email message is required and is 
 * considered valid as long as it is not empty.
 *
 * If the email message fails to validate then an error message is appended 
 * below the message input field.
 */
ContactValidator.prototype.getValidateMessage = function() {
	var me = this;
	return function(event) {
		var value = $(this).val();
		// If value is empty then fail
		if (value == '') {
			$(this).parent('li').append([
				'<span class="inputError">',
					'You must enter a message.',
				'</span>'
			].join(""));
		}
		// If value is non-empty then pass
		else {
			try {
				// Remove the previous error if it now passes
				$('.inputError', $(this).parent('li')).remove();
			} catch (e) { /** Just means it isn't there. **/ }
		}
	};
};

/**
 * This method validates each of the three input fields upon submitting the 
 * form. If the form validates successfully it will be submitted via AJAX. 
 * Otherwise appropriate error messages are displayed and the form is not 
 * submitted.
 *
 *
 * @see getValidateEmail
 * @see getValidateSubject
 * @see getValidateMessage
 */
ContactValidator.prototype.getValidateSubmit = function() {
	var me = this;
	return function(event) {
		var inputElements = [
			$('#contact_email').get(0),
			$('#contact_subject').get(0),
			$('#contact_message').get(0)
		];
		// Validate each element
		for (var i = 0, element; element = inputElements[i]; ++i) {
			$(element).blur();
		}
		
		try {
		if ($('.inputError', $(this)).length == 0) {
			me._contactForm.submitForm(this);
		}
		} catch (e) {/* Do nothing */}
		return false; // Prevent default
	};
};
/**
 *
 * -- Change log --
 * Revision 1 - 2010/09/20 EMM: Removed many small and irrelevant words from 
 * search string.
 *
 * Revision 2 - 2010/09/20 EMM: Qualified subcategory selector so errenreous 
 * <strong> tags did not create false subcategories.
 *
 */



/**
 * FAQ Filter filters/unfilters a FAQ list (based on the current FAQ list 
 * formatting.
 */
FAQFilter = function(selector) {
	this.el = $(selector);
	this.noResults = '<p class="noresults">No Results</p>';
};


/**
 * This method tests a value to see if it matches the current search case 
 * insensitively.
 *
 * @param value - the value being tested.
 * @param searches - and array of values to find.
 * @return true if all values in the array searches exist in value.
 */
FAQFilter.prototype.test = function(value, searches) {
	var numTerms = searches.length;
	var matches = true;
	for(var i = 0; i < numTerms; i++) {
		if (value.indexOf(searches[i]) == -1) {
			matches = false;
			break;
		}
	}
	return matches;
};


/**
 * Update refilters based on new search text, showing new matches and hiding 
 * things that no longer match.
 *
 * This could be dramatically improved by removing common words from the 
 * "searches" array that may prevent otherwise matching questions from being 
 * shown.
 *
 * @param searchtext a string with one or more words.
 *        when empty, all faqs are shown.
 *        when non-empty, uses FAQFilter.test to test each category, sub 
 *        category, and faq leaving only questions or categories that match.
 *
 * @changelog 1
 * @changelog 2
 */
FAQFilter.prototype.update = function(searchtext) {
	var me = this;

	if (searchtext == '') {
		//show everything
		$('*', me.el).show();
		$('.noresults', me.el.parent('div')).remove();
		return;
	}

	//otherwise filter
	// Remove some common and irrelevant words (changelog 1)
	var searches = searchtext.toLowerCase()
		.replace(/\b[\w']{1,3}\b/g, ' ')
		.replace(/\bwhere\b/g, ' ')
		.replace(/\bfind\b/g, ' ')
		.replace(/\blooking\b/g, ' ')
		.replace(/\s{2,}/, ' ')
		.replace(/^\s+/, '')
		.replace(/\s+$/, '')
		.split(' ');

	$('h4', me.el).each(function(){
		var category = $(this);
		var categoryChildren = category.next('ul');
		var categoryMatch = me.test(category.text().toLowerCase(), searches);

		if (categoryMatch) {
			//matches category name, show all faqs
			category.show();
			categoryChildren.show();
			$('*', categoryChildren).show();
			return;
		}

		//when no subcategories match, must hide parent
		// EMM: changelog 2
		var subCategories = $('strong.subcategory', categoryChildren);
		if (subCategories.length == 0) {
			//no subcategories, just check faqs

			//flag to tell whether any faqs match
			var faqMatch = false;

			//check if any faqs match
			$('a', categoryChildren).each(function() {
				var faq = $(this);

				if (me.test(faq.text().toLowerCase(), searches)) {
					faqMatch = true;
					//matches, so show
					faq.parent('li').show();
				} else {
					//doesn't match, so hide
					faq.parent('li').hide();
				}
			});

			if (!faqMatch) {
				//no matching faqs in this category, so hide
				category.hide();
				categoryChildren.hide();
			} else {
				//matching faqs in this category, make sure container is visible
				//   (faqs are already shown/hidden)
				category.show();
				categoryChildren.show();
			}
		} 


		else {
			//flag to tell whether any subcategories match
			var subCategoryMatch = false;

			//check if subcategories match
			subCategories.each(function(){
				var subCategory = $(this);
				var subCategoryChildren = subCategory.next('ul');
				var thisSubCategoryMatch = false;

				if (me.test(subCategory.text().toLowerCase(), searches)) {
					//matches sub category name, so show it and all children
					thisSubCategoryMatch = true;
					subCategory.parent('li').show();
					$('*', subCategoryChildren).show();
				} else {
					//didn't match subcategory name, so check questions
					var faqMatch = false;

					$('a', subCategoryChildren).each(function() {
						var faq = $(this);
						if (me.test(faq.text().toLowerCase(), searches)) {
							faqMatch = true;
							faq.parent('li').show();
						} else {
							faq.parent('li').hide();
						}
					});

					if (faqMatch) {
						//if one question matched, sub category matched
						thisSubCategoryMatch = true;
					}
				}

				if (thisSubCategoryMatch) {
					subCategoryMatch = true;
					//sub category matched, so show
					subCategory.parent('li').show();
				} else {
					//didn't match, so hide
					subCategory.parent('li').hide();
				}
			});

			if (subCategoryMatch) {
				//matching sub categories in this category, make sure container is visible
				//   (categories and faqs are already shown/hidden)
				category.show();
				categoryChildren.show();
			} else {
				//no matching sub categories in this category, so hide
				category.hide();
				categoryChildren.hide();
			}
		}
	});
	
	// Show a "no results" message if everything is hidden (customizable)
	if ($(':visible', me.el).length == 0) {
		if ($('.noresults', me.el.parent('div')).length == 0) {
			$(me.el.parent('div')).append(me.noResults);
		}
	} else {
		$('.noresults', me.el.parent('div')).remove();
	}
};var handler = null;
$(document).ready(function(event) {
	handler = new ContactForm({});
	$('a[href^="/contactus/?"]').click(handler.getOpenContactCallback());
	$('a[href^="/contactus/index"]').click(handler.getOpenContactCallback());
});
