<html>
<head>
<meta HTTP-EQUIV="REFRESH" content="0; url=Animations for Earthquake Terms and Concepts.html">
</head>
</html>
